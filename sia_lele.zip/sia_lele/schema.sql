-- Jalankan di Supabase > SQL Editor
create table accounts (
  kode text primary key, nama text not null,
  tipe text not null check (tipe in ('Aset','Kewajiban','Ekuitas','Pendapatan','Beban'))
);
insert into accounts values
 ('1110','Kas','Aset'),('1120','Piutang Usaha','Aset'),
 ('1210','Persediaan Pakan','Aset'),('1220','Persediaan Bibit Lele','Aset'),
 ('1310','Peralatan','Aset'),('1311','Akumulasi Penyusutan Peralatan','Aset'),
 ('2110','Utang Usaha','Kewajiban'),('3110','Modal Pemilik','Ekuitas'),
 ('4110','Penjualan Lele','Pendapatan'),
 ('5110','Beban Pakan','Beban'),('5120','Beban Bibit','Beban'),
 ('5130','Beban Operasional','Beban'),('5140','Beban Penyusutan','Beban');

create table journals (
  id bigint generated always as identity primary key,
  tanggal date not null, keterangan text, ref_type text
);
create table journal_lines (
  id bigint generated always as identity primary key,
  journal_id bigint references journals(id) on delete cascade,
  kode_akun text references accounts(kode),
  debit numeric default 0, kredit numeric default 0
);
create table purchases (
  id bigint generated always as identity primary key,
  tanggal date, supplier text, kategori text, item text,
  qty numeric, satuan text, harga numeric, total numeric,
  metode text, jatuh_tempo date, lunas boolean default true
);
create table sales (
  id bigint generated always as identity primary key,
  tanggal date, pembeli text, kg numeric, harga_kg numeric, total numeric,
  metode text, lunas boolean default true
);
create table stock_moves (
  id bigint generated always as identity primary key,
  tanggal date, kategori text, item text, qty numeric
);
create table equipment (
  id bigint generated always as identity primary key,
  nama text, tanggal date, harga numeric, umur_bulan int, residu numeric
);

-- Prototype: matikan RLS agar bisa diakses dari app (untuk produksi buat policy + auth)
alter table accounts disable row level security;
alter table journals disable row level security;
alter table journal_lines disable row level security;
alter table purchases disable row level security;
alter table sales disable row level security;
alter table stock_moves disable row level security;
alter table equipment disable row level security;
