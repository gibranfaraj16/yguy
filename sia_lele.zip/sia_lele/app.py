import streamlit as st
import pandas as pd
from datetime import date
from supabase import create_client

st.set_page_config(page_title="SIA Budidaya Lele", page_icon="🐟", layout="wide")

KAS, PIUTANG, UTANG, MODAL, JUAL = "1110", "1120", "2110", "3110", "4110"
AKUN_BELI = {"Pakan": "1210", "Bibit": "1220", "Operasional": "5130"}
AKUN_PAKAI = {"Pakan": ("5110", "1210"), "Bibit": ("5120", "1220")}
PAGES = ["Dashboard", "Pembelian", "Penjualan", "Peralatan", "Akses Cepat"]
AKSES = ["Jurnal Umum", "Buku Besar", "Buku Pembantu", "Neraca", "Laba Rugi"]


# ---------- Helper database ----------
@st.cache_resource
def db():
    try:
        url, key = st.secrets["SUPABASE_URL"], st.secrets["SUPABASE_KEY"]
    except Exception:  # cadangan: baca file kunci.toml (tanpa folder tersembunyi)
        import tomllib
        with open("kunci.toml", "rb") as f:
            cfg = tomllib.load(f)
        url, key = cfg["SUPABASE_URL"], cfg["SUPABASE_KEY"]
    return create_client(url.split("/rest/v1")[0].rstrip("/"), key)


def tbl(nama):
    return pd.DataFrame(db().table(nama).select("*").order("id" if nama != "accounts" else "kode").execute().data)


def rp(x):
    return "Rp " + f"{x:,.0f}".replace(",", ".")


def lines():
    rows = []
    for x in db().table("journal_lines").select("*, journals(tanggal,keterangan,ref_type)").execute().data:
        j = x.pop("journals") or {}
        rows.append({**x, **j})
    return pd.DataFrame(rows, columns=["id", "journal_id", "kode_akun", "debit", "kredit", "tanggal", "keterangan", "ref_type"])


def jurnal(tgl, ket, baris, ref=None):
    """baris = [(kode_akun, debit, kredit), ...] -> wajib balance"""
    assert round(sum(b[1] for b in baris), 2) == round(sum(b[2] for b in baris), 2), "Jurnal tidak balance"
    j = db().table("journals").insert({"tanggal": str(tgl), "keterangan": ket, "ref_type": ref}).execute().data[0]
    db().table("journal_lines").insert(
        [{"journal_id": j["id"], "kode_akun": a, "debit": d, "kredit": k} for a, d, k in baris]).execute()


def saldo():
    a = tbl("accounts").set_index("kode")
    l = lines()
    l[["debit", "kredit"]] = l[["debit", "kredit"]].astype(float)
    a = a.join(l.groupby("kode_akun")[["debit", "kredit"]].sum()).fillna(0)
    dk = a.debit - a.kredit
    a["saldo"] = dk.where(a.tipe.isin(["Aset", "Beban"]), -dk)
    return a


def laba_bersih(a):
    return a[a.tipe == "Pendapatan"].saldo.sum() - a[a.tipe == "Beban"].saldo.sum()


def go(page, akses=None):
    st.session_state.page = page
    if akses:
        st.session_state.ak = akses


# ---------- Dashboard ----------
def dashboard():
    st.title("🐟 Dashboard Budidaya Lele")
    a = saldo()
    sm, pb = tbl("stock_moves"), tbl("purchases")
    laba = laba_bersih(a)

    c1, c2, c3 = st.columns(3)
    c1.metric("Jumlah Kas", rp(a.saldo["1110"]))
    c1.button("Buka Neraca", on_click=go, args=("Akses Cepat", "Neraca"), key="b_kas")
    c2.metric("Profit (Laba/Rugi)", rp(laba), delta="Laba" if laba >= 0 else "Rugi")
    c2.button("Buka Laba Rugi", on_click=go, args=("Akses Cepat", "Laba Rugi"), key="b_laba")
    c3.metric("Total Persediaan", rp(a.saldo["1210"] + a.saldo["1220"]))
    c3.button("Buka Buku Pembantu", on_click=go, args=("Akses Cepat", "Buku Pembantu"), key="b_stok")

    st.subheader("Persediaan")
    d1, d2 = st.columns(2)
    stok = lambda k: sm[sm.kategori == k].qty.sum() if not sm.empty else 0
    d1.metric("Pakan (kg)", f"{stok('Pakan'):,.1f}", help=f"Nilai {rp(a.saldo['1210'])}")
    d2.metric("Bibit (ekor)", f"{stok('Bibit'):,.0f}", help=f"Nilai {rp(a.saldo['1220'])}")

    st.subheader("🔔 Reminder")
    ada = False
    if not pb.empty:
        u = pb[(pb.metode == "Utang") & (~pb.lunas)].copy()
        for _, r in u.iterrows():
            sisa = (pd.to_datetime(r.jatuh_tempo).date() - date.today()).days
            teks = f"Utang ke {r.supplier} ({r['item']}) {rp(r.total)} jatuh tempo {r.jatuh_tempo}"
            if sisa < 0:
                st.error(f"TERLAMBAT {-sisa} hari: {teks}"); ada = True
            elif sisa <= 7:
                st.warning(f"{sisa} hari lagi: {teks}"); ada = True
    key = date.today().strftime("%Y-%m")
    if not tbl("equipment").empty and not sudah_susut(key):
        st.warning(f"Penyesuaian penyusutan bulan {key} belum dijalankan (menu Peralatan).")
        ada = True
    if not ada:
        st.success("Tidak ada reminder.")

    with st.expander("Setoran modal awal"):
        with st.form("modal", clear_on_submit=True):
            tgl, nom = st.date_input("Tanggal", date.today()), st.number_input("Jumlah", min_value=0.0, step=100000.0)
            if st.form_submit_button("Simpan") and nom > 0:
                jurnal(tgl, "Setoran modal pemilik", [(KAS, nom, 0), (MODAL, 0, nom)], "modal")
                st.rerun()


# ---------- Pembelian ----------
def pembelian():
    st.title("🛒 Pembelian")
    with st.form("beli", clear_on_submit=True):
        c = st.columns(3)
        tgl = c[0].date_input("Tanggal", date.today())
        kat = c[1].selectbox("Kategori", list(AKUN_BELI), help="Operasional: listrik, obat, tenaga kerja, dll")
        item = c[2].text_input("Nama barang")
        c = st.columns(4)
        qty = c[0].number_input("Qty", min_value=0.0, step=1.0)
        sat = c[1].text_input("Satuan", "kg")
        harga = c[2].number_input("Harga satuan", min_value=0.0, step=1000.0)
        metode = c[3].selectbox("Pembayaran", ["Tunai", "Utang"])
        supplier = st.text_input("Supplier")
        tempo = st.date_input("Jatuh tempo (jika utang)", date.today())
        if st.form_submit_button("Simpan pembelian") and item and qty * harga > 0:
            total = qty * harga
            db().table("purchases").insert({
                "tanggal": str(tgl), "supplier": supplier, "kategori": kat, "item": item, "qty": qty,
                "satuan": sat, "harga": harga, "total": total, "metode": metode,
                "jatuh_tempo": str(tempo) if metode == "Utang" else None, "lunas": metode == "Tunai"}).execute()
            if kat != "Operasional":
                db().table("stock_moves").insert({"tanggal": str(tgl), "kategori": kat, "item": item, "qty": qty}).execute()
            kredit = KAS if metode == "Tunai" else UTANG
            jurnal(tgl, f"Beli {item}", [(AKUN_BELI[kat], total, 0), (kredit, 0, total)], "beli")
            st.rerun()

    with st.expander("Pemakaian pakan / bibit (kolam)"):
        sm = tbl("stock_moves")
        if sm.empty:
            st.info("Belum ada persediaan.")
        else:
            with st.form("pakai", clear_on_submit=True):
                tgl = st.date_input("Tanggal pakai", date.today())
                pilih = st.selectbox("Item", sorted((sm.kategori + " | " + sm["item"]).unique()))
                jml = st.number_input("Jumlah dipakai", min_value=0.0, step=1.0)
                if st.form_submit_button("Catat pemakaian") and jml > 0:
                    kat, item = pilih.split(" | ")
                    tersedia = sm[(sm.kategori == kat) & (sm["item"] == item)].qty.sum()
                    pb = tbl("purchases")
                    pb = pb[(pb.kategori == kat) & (pb["item"] == item)]
                    if jml > tersedia:
                        st.error(f"Stok hanya {tersedia}")
                    else:
                        hpp = pb.total.sum() / pb.qty.sum() * jml  # biaya rata-rata
                        db().table("stock_moves").insert({"tanggal": str(tgl), "kategori": kat, "item": item, "qty": -jml}).execute()
                        beban, persed = AKUN_PAKAI[kat]
                        jurnal(tgl, f"Pakai {item}", [(beban, hpp, 0), (persed, 0, hpp)], "pakai")
                        st.rerun()

    pb = tbl("purchases")
    if not pb.empty:
        u = pb[(pb.metode == "Utang") & (~pb.lunas)]
        if not u.empty:
            with st.expander("Bayar utang"):
                opsi = {f"#{r.id} {r.supplier} - {r['item']} - {rp(r.total)}": r for _, r in u.iterrows()}
                p = st.selectbox("Pilih utang", list(opsi))
                if st.button("Tandai lunas (bayar tunai)"):
                    r = opsi[p]
                    db().table("purchases").update({"lunas": True}).eq("id", int(r.id)).execute()
                    jurnal(date.today(), f"Bayar utang {r.supplier}", [(UTANG, r.total, 0), (KAS, 0, r.total)], "bayar_utang")
                    st.rerun()
    st.subheader("Transaksi terbaru")
    st.dataframe(pb.sort_values("id", ascending=False).head(15) if not pb.empty else pb, hide_index=True, use_container_width=True)


# ---------- Penjualan ----------
def penjualan():
    st.title("💰 Penjualan")
    with st.form("jual", clear_on_submit=True):
        c = st.columns(3)
        tgl = c[0].date_input("Tanggal", date.today())
        pembeli = c[1].text_input("Pembeli")
        metode = c[2].selectbox("Pembayaran", ["Tunai", "Piutang"])
        c = st.columns(2)
        kg = c[0].number_input("Berat panen (kg)", min_value=0.0, step=1.0)
        hkg = c[1].number_input("Harga per kg", min_value=0.0, step=500.0)
        if st.form_submit_button("Simpan penjualan") and kg * hkg > 0:
            total = kg * hkg
            db().table("sales").insert({"tanggal": str(tgl), "pembeli": pembeli, "kg": kg, "harga_kg": hkg,
                                        "total": total, "metode": metode, "lunas": metode == "Tunai"}).execute()
            jurnal(tgl, f"Jual lele ke {pembeli}", [(KAS if metode == "Tunai" else PIUTANG, total, 0), (JUAL, 0, total)], "jual")
            st.rerun()
    sl = tbl("sales")
    if not sl.empty:
        p = sl[~sl.lunas]
        if not p.empty:
            with st.expander("Pelunasan piutang"):
                opsi = {f"#{r.id} {r.pembeli} - {rp(r.total)}": r for _, r in p.iterrows()}
                pilih = st.selectbox("Pilih piutang", list(opsi))
                if st.button("Terima pembayaran"):
                    r = opsi[pilih]
                    db().table("sales").update({"lunas": True}).eq("id", int(r.id)).execute()
                    jurnal(date.today(), f"Terima piutang {r.pembeli}", [(KAS, r.total, 0), (PIUTANG, 0, r.total)], "terima_piutang")
                    st.rerun()
    st.subheader("Transaksi terbaru")
    st.dataframe(sl.sort_values("id", ascending=False).head(15) if not sl.empty else sl, hide_index=True, use_container_width=True)


# ---------- Peralatan ----------
def sudah_susut(key):
    j = tbl("journals")
    return (not j.empty) and (j.ref_type == f"susut:{key}").any()


def peralatan():
    st.title("🛠️ Peralatan")
    with st.form("alat", clear_on_submit=True):
        c = st.columns(2)
        nama = c[0].text_input("Nama (kolam terpal, pompa, aerator, dll)")
        tgl = c[1].date_input("Tanggal beli", date.today())
        c = st.columns(3)
        harga = c[0].number_input("Harga (dibayar tunai)", min_value=0.0, step=10000.0)
        umur = c[1].number_input("Umur ekonomis (bulan)", min_value=1, value=24)
        residu = c[2].number_input("Nilai residu", min_value=0.0, step=10000.0)
        if st.form_submit_button("Simpan") and nama and harga > 0:
            db().table("equipment").insert({"nama": nama, "tanggal": str(tgl), "harga": harga,
                                            "umur_bulan": int(umur), "residu": residu}).execute()
            jurnal(tgl, f"Beli peralatan {nama}", [("1310", harga, 0), (KAS, 0, harga)], "alat")
            st.rerun()
    e = tbl("equipment")
    if e.empty:
        return
    e["susut_per_bulan"] = (e.harga - e.residu) / e.umur_bulan
    st.dataframe(e, hide_index=True, use_container_width=True)
    key = date.today().strftime("%Y-%m")
    if sudah_susut(key):
        st.success(f"Penyusutan {key} sudah dijalankan.")
    elif st.button(f"Jalankan penyusutan {key} ({rp(e.susut_per_bulan.sum())})"):
        t = e.susut_per_bulan.sum()
        jurnal(date.today(), f"Penyusutan peralatan {key}", [("5140", t, 0), ("1311", 0, t)], f"susut:{key}")
        st.rerun()


# ---------- Akses cepat ----------
def jurnal_umum():
    l, a = lines(), tbl("accounts")[["kode", "nama"]]
    l = l.merge(a, left_on="kode_akun", right_on="kode", how="left")
    st.dataframe(l.sort_values(["tanggal", "journal_id"])[["tanggal", "journal_id", "keterangan", "kode_akun", "nama", "debit", "kredit"]],
                 hide_index=True, use_container_width=True)


def buku_besar():
    a = tbl("accounts")
    pilih = st.selectbox("Akun", (a.kode + " - " + a.nama).tolist())
    x = lines()
    x = x[x.kode_akun == pilih.split(" - ")[0]].sort_values(["tanggal", "id"]).copy()
    x[["debit", "kredit"]] = x[["debit", "kredit"]].astype(float)
    x["saldo (D-K)"] = (x.debit - x.kredit).cumsum()
    st.dataframe(x[["tanggal", "keterangan", "debit", "kredit", "saldo (D-K)"]], hide_index=True, use_container_width=True)


def buku_pembantu():
    jenis = st.radio("Jenis", ["Utang Usaha", "Piutang Usaha", "Persediaan"], horizontal=True)
    if jenis == "Utang Usaha":
        p = tbl("purchases")
        u = p[(p.metode == "Utang") & (~p.lunas)] if not p.empty else p
        st.dataframe(u.groupby("supplier").total.sum().reset_index() if not u.empty else u, hide_index=True)
        st.dataframe(u, hide_index=True, use_container_width=True)
    elif jenis == "Piutang Usaha":
        s = tbl("sales")
        u = s[~s.lunas] if not s.empty else s
        st.dataframe(u.groupby("pembeli").total.sum().reset_index() if not u.empty else u, hide_index=True)
        st.dataframe(u, hide_index=True, use_container_width=True)
    else:
        sm = tbl("stock_moves")
        if not sm.empty:
            st.dataframe(sm.groupby(["kategori", "item"]).qty.sum().reset_index(), hide_index=True)
            st.caption("Kartu stok")
            st.dataframe(sm, hide_index=True, use_container_width=True)


def neraca():
    a = saldo().reset_index()
    laba = laba_bersih(a.set_index("kode"))
    aset = a[a.tipe == "Aset"][["kode", "nama", "saldo"]]
    pas = a[a.tipe.isin(["Kewajiban", "Ekuitas"])][["kode", "nama", "saldo"]]
    pas = pd.concat([pas, pd.DataFrame([{"kode": "-", "nama": "Laba Berjalan", "saldo": laba}])])
    c1, c2 = st.columns(2)
    c1.subheader("Aset"); c1.dataframe(aset, hide_index=True, use_container_width=True)
    c1.metric("Total Aset", rp(aset.saldo.sum()))
    c2.subheader("Kewajiban & Ekuitas"); c2.dataframe(pas, hide_index=True, use_container_width=True)
    c2.metric("Total Kewajiban + Ekuitas", rp(pas.saldo.sum()))


def laba_rugi():
    a = saldo().reset_index()
    for tipe in ["Pendapatan", "Beban"]:
        x = a[a.tipe == tipe][["kode", "nama", "saldo"]]
        st.subheader(tipe); st.dataframe(x, hide_index=True, use_container_width=True)
        st.write(f"Total {tipe}: **{rp(x.saldo.sum())}**")
    laba = laba_bersih(a.set_index("kode"))
    st.metric("Laba / (Rugi) Bersih", rp(laba))


def akses_cepat():
    st.title("⚡ Akses Cepat")
    pilih = st.radio("Laporan", AKSES, horizontal=True, key="ak")
    {"Jurnal Umum": jurnal_umum, "Buku Besar": buku_besar, "Buku Pembantu": buku_pembantu,
     "Neraca": neraca, "Laba Rugi": laba_rugi}[pilih]()


# ---------- Router ----------
if "page" not in st.session_state:
    st.session_state.page = "Dashboard"
st.sidebar.title("SIA Lele")
st.sidebar.radio("Menu", PAGES, key="page")
{"Dashboard": dashboard, "Pembelian": pembelian, "Penjualan": penjualan,
 "Peralatan": peralatan, "Akses Cepat": akses_cepat}[st.session_state.page]()
